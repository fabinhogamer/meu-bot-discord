content = """
services:
  - type: web
    name: youtube-bot
    env: python
    plan: free
    buildCommand: pip install -r requirements.txt
    startCommand: python main.py
"""

with open("render.yaml", "w") as file:
    file.write(content.strip())

print("Arquivo render.yaml criado com sucesso!")