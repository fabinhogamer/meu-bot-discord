import discord
import re

intents = discord.Intents.default()
intents.message_content = True

bot = discord.Client(intents=intents)

# Coloque aqui o ID do canal de notificações
NOTIFICATIONS_CHANNEL_ID = 1363076949907603689 # Substitua pelo ID do canal correto

# Expressão regular para detectar links do YouTube
YOUTUBE_LINK_REGEX = r"(https?://)?(www\.)?(youtube\.com/watch\?v=|youtu\.be/)[\w-]+"

@bot.event
async def on_ready():
    print(f'Bot conectado como {bot.user}')

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    if message.channel.id != NOTIFICATIONS_CHANNEL_ID:
        return

    if re.search(YOUTUBE_LINK_REGEX, message.content):
        await message.channel.send("Legal! Vídeo novo no canal, vamos conferir!")

# Coloque aqui o seu token (entre aspas)
bot.run("MTM3Mjg2MDY4OTE3NzM3ODg0Nw.G1qvZC.LIbcEOFmWoHjgvI5Ukw-Rua4kt265IpxeR94SI")
import pickle
from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ["https://www.googleapis.com/auth/youtube.force-ssl"]

def main():
    flow = InstalledAppFlow.from_client_secrets_file("client_secret.json", SCOPES)
    creds = flow.run_local_server(port=8080)
    with open("token.pkl", "wb") as token_file:
        pickle.dump(creds, token_file)
    print("Autorização concluída. Token salvo em token.pkl")

if __name__ == "__main__":
    main()