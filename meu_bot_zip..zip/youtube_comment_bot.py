import discord
import pickle
import os
import re
from googleapiclient.discovery import build

# Canais desejados
CANAIS_YOUTUBE = [
    "Tinocando TV",
    "Investiga Pinhel",
    "Giuliana Mafra",
    "LocomotivaPop",
    "Ciência Todo Dia"
]

# Mensagens possíveis
MENSAGENS_COMENTARIO = [
    "Adorei esse vídeo!",
    "Muito bom o conteúdo!",
    "Mais um vídeo top!",
    "Esse canal nunca decepciona!",
    "Gostei muito desse tema!"
]

# Função para comentar no vídeo
def comentar_no_video(video_id):
    with open("token.pkl", "rb") as token_file:
        credentials = pickle.load(token_file)

    youtube = build("youtube", "v3", credentials=credentials)

    youtube.commentThreads().insert(
        part="snippet",
        body={
            "snippet": {
                "videoId": video_id,
                "topLevelComment": {
                    "snippet": {
                        "textOriginal": random.choice(MENSAGENS_COMENTARIO)
                    }
                }
            }
        }
    ).execute()
    print(f"Comentário enviado para o vídeo: https://youtu.be/{video_id}")

# Cliente do Discord
intents = discord.Intents.default()
intents.messages = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'Bot conectado como {client.user}')

@client.event
async def on_message(message):
    if message.channel.name == "notificação" and any(canal in message.content for canal in CANAIS_YOUTUBE):
        links = re.findall(r"(https?://[^\s]+)", message.content)
        for link in links:
            if "youtube.com" in link or "youtu.be" in link:
                video_id = None
                if "youtube.com/watch?v=" in link:
                    video_id = link.split("v=")[1].split("&")[0]
                elif "youtu.be/" in link:
                    video_id = link.split("youtu.be/")[1].split("?")[0]
                
                if video_id:
                    comentar_no_video(video_id)

# Substitua pelo seu token do Discord
client.run("MTM3Mjg2MDY4OTE3NzM3ODg0Nw.G1qvZC.LIbcEOFmWoHjgvI5Ukw-Rua4kt265IpxeR94SI")